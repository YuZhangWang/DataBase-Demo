CREATE DEFINER = root@localhost VIEW executivestar AS
SELECT `star`.`name`      AS `name`,
       `star`.`address`   AS `address`,
       `star`.`genre`     AS `genre`,
       `star`.`birthdate` AS `birthdate`,
       `exec`.`cert`      AS `cert`,
       `exec`.`netWorth`  AS `netWorth`
FROM `movie`.`moviestar` `star`
         JOIN `movie`.`movieexec` `exec`
WHERE ((`star`.`name` = `exec`.`name`) AND (`star`.`address` = `exec`.`address`));

