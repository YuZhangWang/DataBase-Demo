CREATE DEFINER = root@localhost VIEW richexec AS
SELECT `movie`.`movieexec`.`name`     AS `name`,
       `movie`.`movieexec`.`address`  AS `address`,
       `movie`.`movieexec`.`cert`     AS `cert`,
       `movie`.`movieexec`.`netWorth` AS `netWorth`
FROM `movie`.`movieexec`
WHERE (`movie`.`movieexec`.`netWorth` >= 10000000);

